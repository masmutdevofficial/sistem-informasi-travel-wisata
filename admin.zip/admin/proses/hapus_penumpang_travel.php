<?php
session_start();
require '../../config/koneksi.php';

try {
    $id = $_POST['id'];
    if (!$id) throw new Exception("ID tidak ditemukan.");

    $stmt = $koneksi->prepare("DELETE FROM data_penumpang_travel WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $_SESSION['success'] = "Data penumpang berhasil dihapus.";
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
}
header("Location: ../data-penumpang-travel.php");
